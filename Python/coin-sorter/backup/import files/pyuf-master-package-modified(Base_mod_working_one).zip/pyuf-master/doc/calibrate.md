### Calibrate

#### For uArm Metal

Please use uArm assistant.


#### For Swift PRO

See https://forum.ufactory.cc/t/official-faq-for-uarm-swift-pro-updating  
or https://drive.google.com/drive/folders/0B-L-tCvknXU9ZXBweVlYRXd5VHM

